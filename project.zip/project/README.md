Open Movie_recommender_system.ipynb file in Colab notebook
Upload ml-100k folder
Run the file